#include <windows.h>
#include <commdlg.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cstring>
#include <io.h>
#include <direct.h>
#include <thread>
#include <mutex>
#include <atomic>
#include "miniz.c"

// --- Global UI Control Handles ---
HWND hLogEdit = NULL;
HWND hBtnExtract = NULL;
HWND hBtnCancel = NULL;
std::atomic<bool> g_cancelRequested(false);
HANDLE g_hThread = NULL;

// --- Custom message for thread-safe logging ---
#define WM_USER_LOG (WM_USER + 100)
#define WM_USER_COMPLETE (WM_USER + 101)

// --- Log Output Function (called from UI thread) ---
void LogMsgUI(const std::string& msg) {
    std::string winMsg;
    for (char c : msg) {
        if (c == '\n') winMsg += "\r\n";
        else winMsg += c;
    }
    int len = GetWindowTextLength(hLogEdit);
    SendMessage(hLogEdit, EM_SETSEL, (WPARAM)len, (LPARAM)len);
    SendMessage(hLogEdit, EM_REPLACESEL, 0, (LPARAM)winMsg.c_str());
    UpdateWindow(hLogEdit);
}

// --- Thread-safe logging: post message to UI thread ---
void LogMsg(const std::string& msg) {
    // Allocate a copy of the string on the heap and pass ownership to the message
    std::string* pMsg = new std::string(msg);
    PostMessage(GetParent(hLogEdit), WM_USER_LOG, 0, (LPARAM)pMsg);
}

// --- Encoding and File System Compatibility (unchanged) ---
std::string utf8_to_ansi(const std::string& utf8) {
    if (utf8.empty()) return "";
    int wlen = MultiByteToWideChar(CP_UTF8, 0, utf8.c_str(), -1, NULL, 0);
    std::wstring wstr(wlen, 0);
    MultiByteToWideChar(CP_UTF8, 0, utf8.c_str(), -1, &wstr[0], wlen);
    int alen = WideCharToMultiByte(CP_ACP, 0, wstr.c_str(), -1, NULL, 0, NULL, NULL);
    std::string ansi(alen, 0);
    WideCharToMultiByte(CP_ACP, 0, wstr.c_str(), -1, &ansi[0], alen, NULL, NULL);
    while (!ansi.empty() && ansi.back() == '\0') ansi.pop_back();
    return ansi;
}

bool file_exists(const std::string& path) {
    return _access(path.c_str(), 0) == 0;
}

std::string get_parent_dir(const std::string& path) {
    size_t pos = path.find_last_of("\\/");
    if (pos != std::string::npos) return path.substr(0, pos);
    return "";
}

void create_directories(const std::string& path) {
    std::string current = "";
    for (char c : path) {
        if (c == '/' || c == '\\') {
            if (!current.empty() && current.back() != ':') {
                _mkdir(current.c_str());
            }
        }
        current += c;
    }
    _mkdir(current.c_str());
}

// --- Data Structures (unchanged) ---
struct XP3Segment {
    bool isCompressed;
    uint64_t offset;
    uint64_t originalSize;
    uint64_t compressedSize;
};

struct XP3FileEntry {
    std::string filename;
    uint64_t originalSize;
    std::vector<XP3Segment> segments;
};

// --- Memory Reader (unchanged) ---
class MemoryReader {
private:
    const uint8_t* data;
    size_t size;
    size_t pos;
public:
    MemoryReader(const std::vector<uint8_t>& buffer) : data(buffer.data()), size(buffer.size()), pos(0) {}
    bool eof() const { return pos >= size; }
    size_t get_pos() const { return pos; }
    void seek(size_t new_pos) { pos = new_pos; }
    uint16_t read_u16() {
        if (pos + 2 > size) return 0;
        uint16_t val = data[pos] | (data[pos+1] << 8); pos += 2; return val;
    }
    uint32_t read_u32() {
        if (pos + 4 > size) return 0;
        uint32_t val = data[pos] | (data[pos+1] << 8) | (data[pos+2] << 16) | (data[pos+3] << 24); pos += 4; return val;
    }
    uint64_t read_u64() {
        if (pos + 8 > size) return 0;
        uint64_t val = 0; for (int i = 0; i < 8; ++i) val |= static_cast<uint64_t>(data[pos++]) << (i * 8); return val;
    }
    std::string read_string(size_t len) {
        if (pos + len > size) return "";
        std::string str(reinterpret_cast<const char*>(data + pos), len); pos += len; return str;
    }
};

std::string utf16le_to_utf8(const std::vector<uint16_t>& u16) {
    std::string u8;
    for (size_t i = 0; i < u16.size(); ++i) {
        uint32_t cp = u16[i];
        if (cp >= 0xD800 && cp <= 0xDBFF && i + 1 < u16.size()) {
            uint32_t trail = u16[++i];
            cp = ((cp - 0xD800) << 10) + (trail - 0xDC00) + 0x10000;
        }
        if (cp < 0x80) u8 += static_cast<char>(cp);
        else if (cp < 0x800) { u8 += static_cast<char>(0xC0 | (cp >> 6)); u8 += static_cast<char>(0x80 | (cp & 0x3F)); }
        else if (cp < 0x10000) { u8 += static_cast<char>(0xE0 | (cp >> 12)); u8 += static_cast<char>(0x80 | ((cp >> 6) & 0x3F)); u8 += static_cast<char>(0x80 | (cp & 0x3F)); }
        else { u8 += static_cast<char>(0xF0 | (cp >> 18)); u8 += static_cast<char>(0x80 | ((cp >> 12) & 0x3F)); u8 += static_cast<char>(0x80 | ((cp >> 6) & 0x3F)); u8 += static_cast<char>(0x80 | (cp & 0x3F)); }
    }
    return u8;
}

// --- XP3Archive class (extraction moved to background) ---
class XP3Archive {
private:
    std::ifstream file;
    std::vector<XP3FileEntry> entries;
    const uint8_t XP3_SIGNATURE[11] = {0x58, 0x50, 0x33, 0x0D, 0x0A, 0x20, 0x0A, 0x1A, 0x8B, 0x67, 0x01};

    uint64_t read_u64_stream() { uint64_t val = 0; file.read(reinterpret_cast<char*>(&val), 8); return val; }

    void parseIndex(const std::vector<uint8_t>& indexData) {
        MemoryReader reader(indexData);
        while (!reader.eof()) {
            std::string chunkId = reader.read_string(4);
            if (chunkId == "File") {
                uint64_t chunkSize = reader.read_u64();
                size_t chunkEnd = reader.get_pos() + chunkSize;
                XP3FileEntry entry;
                while (reader.get_pos() < chunkEnd) {
                    std::string subId = reader.read_string(4);
                    uint64_t subSize = reader.read_u64();
                    size_t subEnd = reader.get_pos() + subSize;
                    if (subId == "info") {
                        reader.read_u32();
                        entry.originalSize = reader.read_u64();
                        reader.read_u64();
                        uint16_t nameLen = reader.read_u16();
                        std::vector<uint16_t> u16name(nameLen);
                        for (int i = 0; i < nameLen; ++i) u16name[i] = reader.read_u16();
                        entry.filename = utf16le_to_utf8(u16name);
                    } else if (subId == "segm") {
                        uint32_t segmentCount = subSize / 28;
                        for (uint32_t i = 0; i < segmentCount; ++i) {
                            XP3Segment seg;
                            uint32_t flags = reader.read_u32();
                            seg.isCompressed = (flags & 1) != 0;
                            seg.offset = reader.read_u64();
                            seg.originalSize = reader.read_u64();
                            seg.compressedSize = reader.read_u64();
                            entry.segments.push_back(seg);
                        }
                    }
                    reader.seek(subEnd);
                }
                entries.push_back(entry);
            } else {
                uint64_t chunkSize = reader.read_u64();
                reader.seek(reader.get_pos() + chunkSize);
            }
        }
    }

public:
    bool open(const std::string& path) {
        file.open(path, std::ios::binary);
        if (!file.is_open()) { LogMsg("Error: Cannot open file " + path + "\n"); return false; }

        uint8_t sig[11]; file.read(reinterpret_cast<char*>(sig), 11);
        if (std::memcmp(sig, XP3_SIGNATURE, 11) != 0) { LogMsg("Error: Invalid signature, not a valid XP3 archive.\n"); return false; }

        uint64_t indexOffset = read_u64_stream(); file.seekg(indexOffset, std::ios::beg);
        uint8_t isCompressed = 0; file.read(reinterpret_cast<char*>(&isCompressed), 1);
        std::vector<uint8_t> indexData;

        if (isCompressed == 1) {
            uint64_t zSize = read_u64_stream(); uint64_t uSize = read_u64_stream();
            std::vector<uint8_t> compressedBuf(zSize); file.read(reinterpret_cast<char*>(compressedBuf.data()), zSize);
            indexData.resize(uSize); mz_ulong destLen = uSize;
            if (uncompress(indexData.data(), &destLen, compressedBuf.data(), zSize) != MZ_OK) {
                LogMsg("Error: Failed to decompress index.\n"); return false;
            }
        } else {
            uint64_t uSize = read_u64_stream(); indexData.resize(uSize);
            file.read(reinterpret_cast<char*>(indexData.data()), uSize);
        }

        parseIndex(indexData);
        return true;
    }

    // Extract in the calling thread (worker thread)
    bool extractAll(const std::string& outFolder) {
        create_directories(outFolder);
        LogMsg("Index parsed successfully! Found " + std::to_string(entries.size()) + " files.\n");
        LogMsg("Starting extraction...\n");

        int current = 1;
        for (const auto& entry : entries) {
            if (g_cancelRequested) {
                LogMsg("Extraction cancelled by user.\n");
                return false;
            }

            std::string ansiFilename = utf8_to_ansi(entry.filename);
            std::string filePath = outFolder + "\\" + ansiFilename;
            for (char& c : filePath) if (c == '/') c = '\\';

            // Periodic progress update
            if (current % 100 == 1 || entries.size() < 100) {
                LogMsg("Extracting [" + std::to_string(current) + "/" + std::to_string(entries.size()) + "] " + entry.filename + "\n");
            }

            std::string parentDir = get_parent_dir(filePath);
            if (!parentDir.empty()) create_directories(parentDir);

            std::ofstream outFile(filePath, std::ios::binary);
            if (!outFile.is_open()) {
                LogMsg("Warning: Cannot create file " + filePath + "\n");
                current++;
                continue;
            }

            for (const auto& seg : entry.segments) {
                file.seekg(seg.offset, std::ios::beg);
                if (seg.isCompressed) {
                    std::vector<uint8_t> compData(seg.compressedSize);
                    file.read(reinterpret_cast<char*>(compData.data()), seg.compressedSize);
                    std::vector<uint8_t> decompData(seg.originalSize);
                    mz_ulong destLen = seg.originalSize;
                    if (uncompress(decompData.data(), &destLen, compData.data(), seg.compressedSize) == MZ_OK) {
                        outFile.write(reinterpret_cast<char*>(decompData.data()), destLen);
                    }
                } else {
                    const size_t BUFFER_SIZE = 1024 * 1024 * 4;
                    std::vector<uint8_t> buffer(BUFFER_SIZE);
                    uint64_t remaining = seg.originalSize;
                    while (remaining > 0) {
                        size_t toRead = std::min(remaining, static_cast<uint64_t>(BUFFER_SIZE));
                        file.read(reinterpret_cast<char*>(buffer.data()), toRead);
                        outFile.write(reinterpret_cast<char*>(buffer.data()), toRead);
                        remaining -= toRead;
                    }
                }
            }
            current++;
        }
        LogMsg("\nExtraction complete! Files saved to: " + outFolder + "\n");
        return true;
    }
};

// --- Worker thread function ---
struct ExtractionParams {
    std::string inputPath;
    std::string outDir;
    HWND hwnd;
};

DWORD WINAPI ExtractionThreadProc(LPVOID lpParam) {
    ExtractionParams* params = static_cast<ExtractionParams*>(lpParam);
    XP3Archive archive;
    bool success = false;

    LogMsg("=====================\n");
    LogMsg("Opening file: " + params->inputPath + "\n");

    if (archive.open(params->inputPath)) {
        success = archive.extractAll(params->outDir);
    }

    // Notify UI thread that extraction is done
    PostMessage(params->hwnd, WM_USER_COMPLETE, (WPARAM)success, 0);
    delete params;
    return 0;
}

// --- Start extraction in background thread ---
void StartExtraction(HWND hwnd, const std::string& inputPath) {
    std::string outDir = inputPath.substr(0, inputPath.find_last_of('.')) + "_extracted";

    EnableWindow(hBtnExtract, FALSE);
    EnableWindow(hBtnCancel, TRUE);
    g_cancelRequested = false;

    ExtractionParams* params = new ExtractionParams{ inputPath, outDir, hwnd };
    g_hThread = CreateThread(NULL, 0, ExtractionThreadProc, params, 0, NULL);
    if (!g_hThread) {
        delete params;
        EnableWindow(hBtnExtract, TRUE);
        EnableWindow(hBtnCancel, FALSE);
        MessageBox(hwnd, "Failed to create worker thread.", "Error", MB_ICONERROR);
    }
}

// --- Run file selection dialog ---
void RunExtraction(HWND hwnd) {
    char szFileName[MAX_PATH] = "";
    OPENFILENAME ofn;
    ZeroMemory(&ofn, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = hwnd;
    ofn.lpstrFilter = "XP3 Archives (*.xp3)\0*.xp3\0All Files (*.*)\0*.*\0";
    ofn.lpstrFile = szFileName;
    ofn.nMaxFile = MAX_PATH;
    ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
    ofn.lpstrDefExt = "xp3";

    if (GetOpenFileName(&ofn)) {
        StartExtraction(hwnd, szFileName);
    }
}

// --- Window Procedure ---
LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
    switch(Message) {
        case WM_CREATE: {
            // Create Buttons
            hBtnExtract = CreateWindowEx(0, "BUTTON", "Select XP3 File and Extract...",
                WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                20, 20, 450, 50, hwnd, (HMENU)1, ((LPCREATESTRUCT)lParam)->hInstance, NULL);

            hBtnCancel = CreateWindowEx(0, "BUTTON", "Cancel",
                WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | WS_DISABLED,
                480, 20, 120, 50, hwnd, (HMENU)2, ((LPCREATESTRUCT)lParam)->hInstance, NULL);

            hLogEdit = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "",
                WS_CHILD | WS_VISIBLE | WS_VSCROLL | ES_MULTILINE | ES_AUTOVSCROLL | ES_READONLY,
                20, 90, 580, 320, hwnd, (HMENU)3, ((LPCREATESTRUCT)lParam)->hInstance, NULL);

            HFONT hFont = CreateFont(16, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Segoe UI"));
            SendMessage(hBtnExtract, WM_SETFONT, (WPARAM)hFont, MAKELPARAM(TRUE, 0));
            SendMessage(hBtnCancel, WM_SETFONT, (WPARAM)hFont, MAKELPARAM(TRUE, 0));
            SendMessage(hLogEdit, WM_SETFONT, (WPARAM)hFont, MAKELPARAM(TRUE, 0));
            break;
        }

        case WM_COMMAND: {
            if (LOWORD(wParam) == 1) {
                RunExtraction(hwnd);
            } else if (LOWORD(wParam) == 2) {
                g_cancelRequested = true;
                EnableWindow(hBtnCancel, FALSE);
            }
            break;
        }

        case WM_USER_LOG: {
            // Receive log message from worker thread
            std::string* pMsg = reinterpret_cast<std::string*>(lParam);
            if (pMsg) {
                LogMsgUI(*pMsg);
                delete pMsg;
            }
            break;
        }

        case WM_USER_COMPLETE: {
            // Extraction finished
            bool success = (bool)wParam;
            EnableWindow(hBtnExtract, TRUE);
            EnableWindow(hBtnCancel, FALSE);
            if (g_hThread) {
                CloseHandle(g_hThread);
                g_hThread = NULL;
            }
            if (success) {
                MessageBox(hwnd, "Extraction completed successfully!", "Info", MB_ICONINFORMATION | MB_OK);
            } else if (!g_cancelRequested) {
                MessageBox(hwnd, "Extraction failed.", "Error", MB_ICONERROR);
            }
            g_cancelRequested = false;
            break;
        }

        case WM_DESTROY: {
            if (g_hThread) {
                g_cancelRequested = true;
                WaitForSingleObject(g_hThread, INFINITE);
                CloseHandle(g_hThread);
            }
            PostQuitMessage(0);
            break;
        }

        default:
            return DefWindowProc(hwnd, Message, wParam, lParam);
    }
    return 0;
}

// --- Main Entry Point ---
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    WNDCLASSEX wc;
    HWND hwnd;
    MSG msg;

    memset(&wc,0,sizeof(wc));
    wc.cbSize        = sizeof(WNDCLASSEX);
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInstance;
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW);
    wc.lpszClassName = "XP3GuiClass";
    wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
    wc.hIconSm       = LoadIcon(NULL, IDI_APPLICATION);

    if(!RegisterClassEx(&wc)) return 0;

    hwnd = CreateWindowEx(0,"XP3GuiClass","XP3 Visual Extractor",
        WS_VISIBLE | WS_SYSMENU | WS_MINIMIZEBOX,
        CW_USEDEFAULT, CW_USEDEFAULT, 640, 480, NULL, NULL, hInstance, NULL);

    if(hwnd == NULL) return 0;

    while(GetMessage(&msg, NULL, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return msg.wParam;
}